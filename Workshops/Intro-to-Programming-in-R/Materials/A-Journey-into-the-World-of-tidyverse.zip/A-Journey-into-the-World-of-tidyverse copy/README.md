# A Journey into the World of Tidyverse


## About The Coffee, Cookie and Coding $\left(C^3\right)$ Workshops

Yale’s [Public Health Data Science and Data Equity (DSDE)](https://ysph.yale.edu/research/research-centers-and-initiatives/public-health-data-science-and-data-equity/) team hosts workshops, tutorials, and information sessions known as Coffee, Cookie and Coding $\left(C^3\right)$ Workshops. These sessions are designed to help Public Health and Biostatistics masters-level students at Yale effectively leverage computational tools and analytical methods in their educational and professional endeavors.

While primarily intended for the Yale community, all are welcome and encouraged to attend and benefit from our offerings. If you are affiliated with Yale, you can set up an office hour appointment with one of the data scientists ([Bookings Page](https://outlook.office365.com/owa/calendar/DataScienceDataEquityOfficeHours@yale.edu/bookings/)).

You can find out more about past and upcoming work on our [website](https://ysph.yale.edu/public-health-research-and-practice/research-centers-and-initiatives/public-health-data-science-and-data-equity/events/). Additional tutorials will soon be available on our YouTube channel. 


## About Workshop

**Workshop Title:** &nbsp; A Journey into the World of Tidyverse

**Last Updated:** &nbsp;&nbsp;&nbsp;&nbsp; February $16^{\text{th}}$, 2026

**Part 2 Instructors:**

- [Shelby Golden, M.S.](https://ysph.yale.edu/profile/shelby-golden/), Data Scientist I
- [Howard Baik, M.S.](https://www.linkedin.com/in/howard-baik/), Former Data Scientist I at Yale School of Public Health

Upon completing the workshop, you will be able to:

- Explore the tidyverse ecosystem and its integrated approach to data analysis using domain specific language.
- Develop proficiency with `tidyr`, `dplyr`, and `stringr` with a real-world worked-through example.
- Practice data manipulation skills by answering prepared questions using COVID-19 data.

## Overview Of Contents

- **For the questions:** `Questions.R`
- **For the solutions:** `Solutions.R`
- **R:** version 4.5.2
- **RStudio IDE:** version 2026.01.0+392
- **`renv`:** version 1.1.7. Included to reproduce the coding environment.

All session materials, interactive learning assignments, and codebase links are available in the [Book of Workshops](https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Git-and-GitHub/git-github-index.html) chapter. Some of these materials have been adapted for asynchronous learning in webpage format.

## Using this Repository

We have prepared challenge questions with answers for the hands-on workshop. To use them, download and set up the codebase. See instructions below unde [Accessing the Codespaces](https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Intro-to-Programming-in-R/programming-r-index.html#accessing-the-codespaces) section of this workshop's Book of Workshops webpage.

Please note that all slides, handouts, and code provided in this workshop, including any added to your personal repository, belongs to DSDE. When using or referencing this material, please ensure to cite it correctly to give proper credit to the original authors.

## About the Data

The [Johns Hopkins Coronavirus Resource Center](https://coronavirus.jhu.edu/) (JHU CRC) tracked and compiled global COVID-19 pandemic data from January 22, 2020, to March 10, 2023. This data is publicly available through their two GitHub repositories. For this workshop content, we imported the cumulative case and death counts for the U.S. from their [CSSEGISandData](https://github.com/CSSEGISandData/COVID-19) GitHub repository. The raw data for these two datasets used in the analysis can be found in the `csse_covid_19_data/csse_covid_19_time_series` subdirectory ([original source](https://github.com/CSSEGISandData/COVID-19/tree/master/csse_covid_19_data/csse_covid_19_time_series)). Both `time_series_covid19_confirmed_US.csv` and `time_series_covid19_deaths_US.csv` were used.

The data dictionary provided by JHU CRC can be found here: [Cases and Deaths Datasets Data Dictionary](https://github.com/CSSEGISandData/COVID-19/tree/master/csse_covid_19_data#usa-daily-state-reports-csse_covid_19_daily_reports_us). For our purposes, we conducted data cleaning, harmonization, and smoothing using isotonic regression. This included harmonizing the U.S. Census Bureau's 2010 to 2019 population projections with the 2020 to 2023 vintages.

Details about these steps can be found in the `Intro-to-Programming-in-R/Code` directory ([link to code](https://github.com/ysph-dsde/Book-of-Workshops/tree/main/Workshops/Intro-to-Programming-in-R/Code)). The cleaned datasets are in the `Intro-to-Programming-in-R/Data` directory ([link to data](https://github.com/ysph-dsde/Book-of-Workshops/tree/main/Workshops/Intro-to-Programming-in-R/Data)).

## References

1. Dr. B. Moss, Dr. C. Watson, Dr. L. Rutkow, Dr. B. Garibaldi, B. Blauer, and Dr. L. Gardner, “Johns Hopkins Coronavirus Resource Center.” Accessed: Oct. 14, 2024. [Online]. Available: https://coronavirus.jhu.edu/

2. Johns Hopkins University Coronavirus Resource Center, “CSSEGISandData,” Center for Systems Science and Engineering (CSSE). Accessed: Nov. 02, 2024. [Online]. Available: https://github.com/CSSEGISandData/COVID-19

3. Johns Hopkins University Coronavirus Resource Center, “CSSEGISandData Data Dictionary,” Center for Systems Science and Engineering (CSSE). Accessed: Nov. 09, 2025. [Online]. Available: https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Git-and-GitHub/git-github-index.html
  
4. Johns Hopkins University Coronavirus Resource Center, “Time Series COVID-19 Cases and Deaths US,” Center for Systems Science and Engineering (CSSE). Accessed: Nov. 09, 2025. [Online]. Available: https://github.com/CSSEGISandData/COVID-19/tree/master/csse_covid_19_data/csse_covid_19_time_series

5. Shelby Golden and Howard Baik, “Introduction to Programming in R and Data Wrangling with `tidyverse`,” Book of Workshops. Accessed: Feb. 16, 2026. [Online]. Available: https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Intro-to-Programming-in-R/programming-r-index.html

