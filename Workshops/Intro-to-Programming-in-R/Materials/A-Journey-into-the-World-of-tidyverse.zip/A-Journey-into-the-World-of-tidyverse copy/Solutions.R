## ----------------------------------------------------------------------------
## Produced by Yale's Public Health Data Science and Data Equity (DSDE) team
##
##     Workshop: A Journey Into The World of tidyverse
##      Authors: Shelby Golden, M.S. and Howard Baik, M.S.
## Last Updated: 2026-02-16
## 
##       R version: 4.5.2
## RStudio version: 2026.01.0+392
##    renv version: 1.1.7


## ----------------------------------------------------------------------------
## SET UP THE ENVIRONMENT
## renv() will install all of the packages and their correct version used here
renv::init()          # Initialize the project
renv::restore()       # Download packages and their version saved in the lockfile.

suppressPackageStartupMessages({
  library("readr")      # For reading in the data
  library("tidyr")      # For tidying data 
  library("dplyr")      # For data manipulation 
  library("stringr")    # For string manipulation
})


# Function to select "Not In"
'%!in%' <- function(x,y)!('%in%'(x,y))




## ----------------------------------------------------------------------------
## LOAD IN THE DATA

# Read COVID-19 death data
df_url <- "https://raw.githubusercontent.com/ysph-dsde/Book-of-Workshops/refs/heads/main/Workshops/Intro-to-Programming-in-R/Data/Data%20for%20the%20Questions_Aggregated%20by%20Month.csv"
df     <- read_csv(file = df_url) #, show_col_types = FALSE)




## ----------------------------------------------------------------------------
## SOLUTIONS

## 1.  Filter the `df` data set to include only rows from 2021.

covid19_death_2021 <- df |> 
  filter(Month >= "2021-01-01" & Month <= "2021-12-31")




## 2.  With the data set filtered for rows from 2021, determine the day with the 
##     highest death count along with the corresponding count.

covid19_death_2021 |> 
  filter(Deaths_Count == max(covid19_death_2021$Deaths_Count))




## 3.  We want to see how many counties called "Adams" are represented in the 
##     data set.
##        a)  Subset the data set by string matches in `County` and find how 
##            many rows you see. Remember that each county is expected to have 
##            39 different dates reported.
##        b)  Table your subset results by `County` and `Province_State`. Does 
##            this change the answer you got from part a?


## --------------------
## part a

df_adams_counties <- df[str_detect(df$Combined_Key, "Adams"), ]
str_c("There are ", nrow(df_adams_counties)/39, " counties called Adams in the US.")

## --------------------
## part b
table(df_adams_counties$County, df_adams_counties$Province_State)










