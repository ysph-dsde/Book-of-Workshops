# Code Smarter, Not Harder: Unlocking AI-Assisted Coding


## About The Coffee, Cookie and Coding $\left(C^3\right)$ Workshops

Yale’s [Public Health Data Science and Data Equity (DSDE)](https://ysph.yale.edu/research/research-centers-and-initiatives/public-health-data-science-and-data-equity/) team hosts workshops, tutorials, and information sessions known as Coffee, Cookie and Coding $\left(C^3\right)$ Workshops. These sessions are designed to help Public Health and Biostatistics masters-level students at Yale effectively leverage computational tools and analytical methods in their educational and professional endeavors.

While primarily intended for the Yale community, all are welcome and encouraged to attend and benefit from our offerings. If you are affiliated with Yale, you can set up an office hour appointment with one of the data scientists ([Bookings Page](https://outlook.office365.com/owa/calendar/DataScienceDataEquityOfficeHours@yale.edu/bookings/)).

You can find out more about past and upcoming work on our [website](https://ysph.yale.edu/public-health-research-and-practice/research-centers-and-initiatives/public-health-data-science-and-data-equity/events/). Additional tutorials will soon be available on our YouTube channel. 


## About Workshop

**Workshop Title:** &nbsp; Code Smarter, Not Harder: Unlocking AI-Assisted Coding

**Last Updated:** &nbsp;&nbsp;&nbsp;&nbsp; March 23\textsuperscript{rd}, 2026

**Instructor:** [Shelby Golden, M.S.](https://ysph.yale.edu/profile/shelby-golden/), Data Scientist I

Upon completing the workshop, you will be able to:

- **Foundational AI Literacy:** Explain AI's evolution from Alan Turing to the modern day, distinguish between AI system types, and better articulate what AI is and isn't.
- Understand the AI coding tool landscape, learn best practices for prompts and verification, and identify and navigate common pitfalls.
- Replicate the results of a paper using Yale's AI Clarity LLM and Positron's native IDE assistant, practicing prompting, iteration, debugging, and comparing the systems.

## Overview Of Contents

- **For the questions:** `Worked-Through Example.R`
- **For the solutions:** `Worked-Through Example_Solutions.R`
- **R:** version 4.5.2
- **Positron IDE:** version 2026.01.0+392
- **`renv`:** version 1.1.7. Included to reproduce the coding environment.

All session materials, interactive learning assignments, and codebase links are available in the [Book of Workshops](https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Code-Smarter-Not-Harder/ai-coding-index.html) chapter. Some of these materials have been adapted for asynchronous learning in webpage format.

## Using this Repository

We have prepared a script outline (with solutions) for the workshop’s hands-on component. To use these materials, download the codebase and complete the setup steps. Participants will also need access to an LLM chatbot and the ability to configure an IDE-based AI assistant with a provider. Full setup instructions—including steps for enabling GitHub Copilot—are provided in the workshop’s Book of Workshops page under [Accessing the Codespaces](https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Code-Smarter-Not-Harder/ai-coding-index.html#accessing-the-codespaces).

Please note that all slides, handouts, and code provided in this workshop, including any added to your personal repository, belongs to DSDE. When using or referencing this material, please ensure to cite it correctly to give proper credit to the original authors.

## About the Data

In this workshop, we aim to reproduce selected summary statistics and figures from Thomas et al. (2023), [“Healthy Lifestyle Behaviors and Biological Aging in the U.S. National Health and Nutrition Examination Surveys, 1999–2018”](https://pmc.ncbi.nlm.nih.gov/articles/PMC10460553/). This paper used the Continuous [National Health and Nutrition Examination Survey (NHANES)](https://www.cdc.gov/nchs/nhanes/index.html) dataset, which provides information on participants' eating and exercise habits, anthropometric measurements, and lab results.

The continuous series was launched in 1999 and has been conducted biennially since then. NHANES is a cross-sectional study that uses a stratified, multistage, probability-clustered sample of approximately 5,000 participants from 15 counties and includes sampling weights to generate nationally representative estimates. The authors applied the PhenoAge algorithm to predict participants' biological age using the "Levine Original" formula (9 biomarkers) from the `BioAge` R package, which was trained on NHANES-III data (collected 1988–94): package [paper](https://link.springer.com/article/10.1007/s11357-021-00480-5) and [documentation](https://github.com/dayoonkwon/BioAge).

Based on the methods section, the paper implies the use of sample weights to generate national estimates. Weight selection varies depending on which data files you're combining, and weighted datasets require survey-specific functions for analysis (e.g., `svyglm` instead of `glm`). However, the `BioAge` R package doesn't appear to use weighted NHANES-III data when training the PhenoAge model. For consistency and simplicity, we skipped the weights in this example and focused on participant-level results instead.

Minimal differences in sample size were observed between our pipeline and the paper up until the pre-calculated PhenoAge values were assessed. At that step, approximately 10,000 more participants were identified as having missing PhenoAge values than reported in the paper.

Much of the data preparation has been conducted in the background so this example can remain focused on AI-assisted coding techniques. If you want to review the complete data processing steps, along with links to the full data dictionary associated with the NHANES datasets used, see ["Code/Data Cleaning/Import and Compiling Continuous NHANES 1999 to 2018.R"](https://github.com/ysph-dsde/Book-of-Workshops/tree/main/Workshops/Code-Smarter-Not-Harder/Code/Data%20Cleaning). All datasets generated for this workshop can be found in ["Code/Data."](https://github.com/ysph-dsde/Book-of-Workshops/tree/main/Workshops/Code-Smarter-Not-Harder/Data)

## References

1. A. Thomas, D. W. Belsky, and Y. Gu, “Healthy Lifestyle Behaviors and Biological Aging in the U.S. National Health and Nutrition Examination Surveys 1999–2018,” J Gerontol A Biol Sci Med Sci, vol. 78, no. 9, pp. 1535–1542, Mar. 2023, doi: 10.1093/gerona/glad082.

2. A. Trichopoulou, T. Costacou, C. Bamia, and D. Trichopoulos, “Adherence to a Mediterranean Diet and Survival in a Greek Population,” New England Journal of Medicine, vol. 348, no. 26, pp. 2599–2608, Jun. 2003, doi: 10.1056/NEJMoa025039.

3. A. Trichopoulou et al., “Diet and overall survival in elderly people,” BMJ, vol. 311, no. 7018, pp. 1457–1460, Dec. 1995, doi: 10.1136/bmj.311.7018.1457.

4. A. Y. Maslov and J. Vijg, “Genome instability, cancer and aging,” Biochim Biophys Acta, vol. 1790, no. 10, pp. 963–969, Oct. 2009, doi: 10.1016/j.bbagen.2009.03.020.

5. Centers for Disease Control and Prevention (CDC) and National Center for Health Statistics (NCHS), “Datasets and Documentation,” National Health and Nutrition Examination Survey. Accessed: Mar. 10, 2026. [Online]. Available: https://wwwn.cdc.gov/nchs/nhanes/tutorials/Datasets.aspx

6. Centers for Disease Control and Prevention (CDC) and National Center for Health Statistics (NCHS), “Guidelines for High Quality Analyses of NHANES Data,” National Health and Nutrition Examination Survey. Accessed: Mar. 10, 2026. [Online]. Available: https://wwwn.cdc.gov/nchs/nhanes/QualityAnalysesGuidelines.aspx

7. Centers for Disease Control and Prevention (CDC) and National Center for Health Statistics (NCHS), “National Health and Nutrition Examination Survey,” National Health and Nutrition Examination Survey. Accessed: Mar. 16, 2026. [Online]. Available: https://www.cdc.gov/nchs/nhanes/index.html


8. D. Kwon and D. W. Belsky, “A toolkit for quantification of biological age from blood chemistry and organ function test data: BioAge,” GeroScience, vol. 43, no. 6, pp. 2795–2808, Dec. 2021, doi: 10.1007/s11357-021-00480-5.

9. D. Kwon, BioAge GitHub Repository. (Mar. 19, 2026). R. GitHub. Accessed: Mar. 21, 2026. [Online]. Available: https://github.com/dayoonkwon/BioAge

10. J. Rutledge, H. Oh, and T. Wyss-Coray, “Measuring biological age using omics data,” Nat Rev Genet, vol. 23, no. 12, pp. 715–727, Dec. 2022, doi: 10.1038/s41576-022-00511-7.

11. Kyle Grealis, nhanesdata GitHub Repository. R. GitHub. Accessed: Mar. 10, 2026. [Online]. Available: https://github.com/kyleGrealis/nhanesdata

12. Kyle Grealis, “nhanesdata Webpage.” Accessed: Mar. 10, 2026. [Online]. Available: https://www.kylegrealis.com/nhanesdata/index.html

13. Kyle Grealis, Why Survey Weights Matter. (Feb. 28, 2026). Cran R. Accessed: Mar. 21, 2026. [Online]. Available: https://cran.r-project.org/web/packages/nhanesdata/vignettes/survey-design.html

14. Food Surveys Research Group, National Center for Health Statistics (NCHS), and Centers for Disease Control and Prevention (CDC), “Body Measures (BMX) Data Documentation, Codebook, and Frequencies Dietary Interview - 1999-2000.” U.S. Department of Agriculture (USDA), Beltsville, MD, Jun. 2002. Accessed: Mar. 09, 2026. [Online]. Available: https://wwwn.cdc.gov/nchs/data/nhanes/public/1999/datafiles/BMX.htm

15. Food Surveys Research Group, National Center for Health Statistics (NCHS), and Centers for Disease Control and Prevention (CDC), “Demographic Variables & Sample Weights (DEMO) Data Documentation, Codebook, and Frequencies Dietary Interview - 1999-2000.” U.S. Department of Agriculture (USDA), Beltsville, MD, Jun. 2002. Accessed: Mar. 09, 2026. [Online]. Available: https://wwwn.cdc.gov/nchs/data/nhanes/public/1999/datafiles/DEMO.htm

16. Food Surveys Research Group, National Center for Health Statistics (NCHS), and Centers for Disease Control and Prevention (CDC), “Individual Foods, Second Day (DR1IFF_L) Data Documentation, Codebook, and Frequencies Dietary Interview - August 2021-August 2023.” U.S. Department of Agriculture (USDA), Beltsville, MD, Oct. 2024. Accessed: Mar. 09, 2026. [Online]. Available: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/DR1IFF_L.htm

17. Food Surveys Research Group, National Center for Health Statistics (NCHS), and Centers for Disease Control and Prevention (CDC), “Individual Foods, Second Day (DR2IFF_L) Data Documentation, Codebook, and Frequencies Dietary Interview - August 2021-August 2023.” U.S. Department of Agriculture (USDA), Beltsville, MD, Oct. 2024. Accessed: Mar. 09, 2026. [Online]. Available: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/DR2IFF_L.htm

18. Food Surveys Research Group, National Center for Health Statistics (NCHS), and Centers for Disease Control and Prevention (CDC), “Physical Activity - Individual Activities (PAQIAF) Data Documentation, Codebook, and Frequencies Dietary Interview - 1999-2000.” U.S. Department of Agriculture (USDA), Beltsville, MD, Sep. 2004. Accessed: Mar. 09, 2026. [Online]. Available: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/1999/DataFiles/PAQIAF.htm#PADTIMES

19. Food Surveys Research Group, National Center for Health Statistics (NCHS), and Centers for Disease Control and Prevention (CDC), “Physical Activity (PAQ_E) Data Documentation, Codebook, and Frequencies Dietary Interview - 1999-2000.” U.S. Department of Agriculture (USDA), Beltsville, MD, Mar. 2017. Accessed: Mar. 09, 2026. [Online]. Available: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2007/DataFiles/PAQ_E.htm#PAD615

20.	M. E. Levine et al., “An epigenetic biomarker of aging for lifespan and healthspan,” Aging (Albany NY), vol. 10, no. 4, pp. 573–591, Apr. 2018, doi: 10.18632/aging.101414.

21. National Center for Health Statistics (NCHS) and Centers for Disease Control and Prevention (CDC), “NHANES Dietary Analyses Module,” NHANES Tutorials. Accessed: Mar. 10, 2026. [Online]. Available: https://wwwn.cdc.gov/nchs/nhanes/tutorials/dietaryanalyses.aspx

22. National Center for Health Statistics (NCHS) and Centers for Disease Control and Prevention (CDC), “NHANES Weighting,” NHANES Tutorials. Accessed: Mar. 10, 2026. [Online]. Available: https://wwwn.cdc.gov/nchs/nhanes/tutorials/Weighting.aspx

23. Shelby Golden and Howard Baik, “Introduction to Programming in R and Data Wrangling with `tidyverse`,” Book of Workshops. Accessed: Feb. 16, 2026. [Online]. Available: https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Intro-to-Programming-in-R/programming-r-index.html

24. UCLA: Statistical Consulting Group, “Survey Data Analysis with R,” Seminars. Accessed: Mar. 10, 2026. [Online]. Available: https://stats.oarc.ucla.edu/r/seminars/survey-data-analysis-with-r/



