## ----------------------------------------------------------------------------
## From Yale's Public Health Data Science and Data Equity (DSDE) Team
## Coffee, Cookies, and Coding (C-Cubed) Workshops
##
## Data Visualization with ggplot2
##
##  Author: Shelby Golden, M.S.
##    Date: 2025-03-18
## Updated: 2025-11-19
## 
##.   R version: 4.5.1
## renv version: 1.1.5
## 
## Description: Enclosed are the discussion questions from the lecture, along 
##              with code to help answer them. Towards the end, you'll find a 
##              few challenge questions to test your understanding. Keep in mind 
##              that there are various ways to create the same graph, so your 
##              answer might look different from mine and still be correct!


## ----------------------------------------------------------------
## SET UP THE ENVIRONMENT

# NOTE: renv initialization might need to be run twice after the repo is
#       first copied.
# renv::init()
renv::restore()

suppressPackageStartupMessages({
  library("arrow")        # For reading in the data
  library("dplyr")        # For data manipulation
  library("ggplot2")      # For creating static visualizations
  library("plotly")       # For interactive plots
  library("cowplot")      # ggplot add-on for composing figures
  library("tigris")       # Imports TIGER/Line shapefiles from the Census Bureau
  library("sf")           # Handles "Simple Features": spatial vector data
  library("RColorBrewer") # Load ColorBrewer color palettes
  library("viridis")      # Load the Viridis color palette
})

# Function to select "Not In"
'%!in%' <- function(x, y)!('%in%'(x, y))




## ----------------------------------------------------------------
## LOAD THE DATASETS

# Load the RSV-NET Infections dataset used in the workshop.
url <- "https://github.com/ysph-dsde/Book-of-Workshops/raw/refs/heads/main/Workshops/Data-Visualization-with-ggplot2/Data/RSV-NET%20Infections.gz.parquet"
df <- read_parquet(url)

# Load the diamonds dataset provided with the ggplot2 package installation.
data("diamonds")

# Call the TIGER/Line Shapefiles from the Census Bureau.
us_geo <- tigris::states(class = "sf", cb = TRUE) |>
  # Translate the geometric locations for Alaska and Hawaii to plot underneath
  # the contiguous states.
  shift_geometry()




## ----------------------------------------------------------------
## LECTURE DISCUSSIONS

## You can find the context for these discussion questions by reviewing
## the slides and the Book of Workshops webpage for the worked-through example:
## https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Data-Visualization-with-ggplot2/Pages/visualization-worked-through-example.html


## ---------------------
## DISCUSSION #1 - THE GEOMETRY LAYER

## The following two plots give the same results but map the aesthetics in
## different layers.

# Map aesthetics in the plot object layer
df |>
  filter(Region == "Connecticut", Season == "2021-22", Level == "N/A") |>
  ggplot(aes(x = MMWRweek, y = Kernel)) +
    geom_line()

# Map aesthetics in the Geometry layer
df |>
  filter(Region == "Connecticut", Season == "2021-22", Level == "N/A") |>
  ggplot() +
    geom_line(aes(x = MMWRweek, y = Kernel))


## Can you think of reasons why you would choose one over the other?




## ---------------------
## DISCUSSION #2 - THE SCALES LAYER

# Specify the infection seasons we'd like to see out of the range of options
include_seeasons <- c("2022-23", "2023-24", "2024-25")

## We see that associating a variable with aes(color) will also group by that 
## same variable.

# Use Scales to highlight insights into infection trends across seasons
df |>
  filter(Region == "Connecticut", Season %in% include_seeasons, Level == "N/A") |>
  ggplot(aes(x = MMWRweek, y = Kernel, color = Season) ) +
    geom_line()


## a. What would happen if we only group the outcomes and exclude the color statement: 
##    i.e., aes(group = Season)?

## b. Does adding a scale_color_*() statement change the result?

## c. Why do you see the result you get?




## ---------------------
## DISCUSSION #3 - THE COORDINATES LAYER

## In this discussion, we will follow the example laid out in the ggplot2
## package documentation for coord_trans().
## 
## Link: https://ggplot2.tidyverse.org/reference/coord_trans.html
## 
## The example uses one of the sample datasets included with the ggplot2
## installation. The "diamonds" dataset includes characteristics of diamonds,
## such as their price, carat, cut, clarity, and color.
## 
## We will compare the price of diamonds against their carat. Both variables
## will need to be transformed using a base 10 log.

# The basic, un-transformed plot.
ggplot(diamonds, aes(carat, price)) +
  stat_bin2d() + 
  geom_smooth(method = "lm")

## a. Create three separate plots applying the following modifications to the
##    basic plot above.
##      - Transform the variables in aes() with log10()
##      - Add a Scales layer: scale_*_log10() or scale_*_continuous(trans = "log10")
##      - Add a Coordinates with Scales layer: coord_trans(x = pow10) with
##        pow10 <- scales::exp_trans(10)



## b. Do they all plot the same way? If not, what do you think is happening and 
##    how would you fix the code?




## ----------------------------------------------------------------
## CHALLENGE QUESTIONS

## ---------------------
## QUESTION #1 - THE FACETS LAYER

# Copying the subsetting vectors for Season and Characteristic Level
include_seeasons <- c("2022-23", "2023-24", "2024-25")
ages_ordered <- c("5-17 Years", "18-49 Years", "75+ Years")

# Copying the data subsetting code to get the leading point
leading_point = df |> 
  filter(Region == "Connecticut", Season %in% include_seeasons, 
         Level %in% ages_ordered) |>
  filter(MMWRyear == max(MMWRyear)) |>
  filter(MMWRweek == max(MMWRweek))


## In the worked-through example, we leverage two of the three distinguishing
## variables: Season and Characteristic Level. In this question, we want to
## focus on the third one, Region.
##
## Recall the available outcomes for Region.
df$Region |> unique()


## Using the final line-graph code from the worked-through example, add a
## row-wise facet to compare two states or HHS regions.

# Modify the following block of code.
df |>
  filter(Region == "Connecticut", Season %in% include_seeasons, Level %in% ages_ordered) |>
  ggplot(aes(x = MMWRweek, y = Kernel, color = Season) ) +
    geom_line() +
    geom_point(data = leading_point, aes(x = MMWRweek, y = Kernel), 
               color = "red") +
    labs(title = "RSV Infection Trends Since 2022",
         x = "Weeks Since July", 
         y = "Positive RSV Tests\nResults Scaled and Gaussian Kernel Smoothed") +
    ylim(0, 100) +
    scale_color_brewer(type = "qual", palette = "Dark2") +
    facet_grid(~factor(Level, levels = ages_ordered)) + 
    theme_linedraw()




## ---------------------
## QUESTION #2 - OVERLAYING LAYERS

## In the polished version of the line plot, we layered an additional point
## on the graph to highlight the most recent date in the active infection season.
## To get this data, we externally filtered down the dataset to get that point,
## repeating some of the filtering we are already doing before the plot gets 
## generated.
##
## a. Can you modify this approach so that we no longer require the external
##    dataset, thus simplifying our code?
## 
## b. Now try using stat_summary(filtered_data, geom = "point", fun = "max", 
##    color = "red") instead of geom_point(). If you only filter to MMWRyear, do
##    you get the same result, and if not why?

# Modify the following two blocks of code.
leading_point = df |> 
  filter(Region == "Connecticut", Season %in% include_seeasons, 
         Level %in% ages_ordered) |>
  filter(MMWRyear == max(MMWRyear)) |>
  filter(MMWRweek == max(MMWRweek))

df |>
  filter(Region == "Connecticut", Season %in% include_seeasons, Level %in% ages_ordered) |>
  ggplot(aes(x = MMWRweek, y = Kernel, color = Season) ) +
  geom_line() +
  geom_point(data = leading_point, aes(x = MMWRweek, y = Kernel), 
             color = "red") +
  labs(title = "RSV Infection Trends Since 2022",
       x = "Weeks Since July", 
       y = "Positive RSV Tests\nResults Scaled and Gaussian Kernel Smoothed") +
  ylim(0, 100) +
  scale_color_brewer(type = "qual", palette = "Dark2") +
  facet_grid(~factor(Level, levels = ages_ordered)) + 
  theme_linedraw()




## ---------------------
## QUESTION #3 - MAP PROJECTIONS

# Copying the data subsetting code
subset <- df |>
  filter(Region %in% c(datasets::state.name, "District of Columbia"),
         Season %in% "2024-25", MMWRweek %in% c(24:26))

# Copying the data joining and filtering code to add the SF polygons to our
# RSV infections metadata
geo_df <- us_geo |> 
  left_join(subset, c("NAME" = "Region")) |>
  filter(GEOID < 60)

## In our line graph, we faceted by age groups. However, when we apply a
## simple Facet layer to our map plot, the NA values get plotted in their 
## own panel.
## 
## a. Why is this happening?
## b. Fix this code to prevent this panel from being generated.

# Modify the following block of code.
geo_df |>
  ggplot(aes(fill = Kernel), color = "black") +
    geom_sf() +
    scale_fill_viridis(direction = -1, na.value = "grey92") +
    labs(fill = NULL, title = "Peak 2024-25 Season RSV Infection Trends\nResults Scaled and Gaussian Kernel Smoothed") +
    facet_grid(~factor(Level, levels = ages_ordered)) +
    coord_sf() +
    theme_map()




