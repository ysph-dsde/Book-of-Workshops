## ----------------------------------------------------------------------------
## From Yale's Public Health Data Science and Data Equity (DSDE) Team
## Coffee, Cookies, and Coding (C-Cubed) Workshops
##
## Data Visualization with ggplot2
##
##  Author: Shelby Golden, M.S.
##    Date: 2025-03-18
## Updated: 2025-11-19
## 
##.   R version: 4.5.1
## renv version: 1.1.5
## 
## Description: Enclosed are the solutions to the discussion and challenge 
##              questions from the lecture. Remember that there are various 
##              ways to create the same graph, so your answer might look 
##              different from mine and still be correct!


## ----------------------------------------------------------------
## SET UP THE ENVIRONMENT

# NOTE: renv initialization might need to be run twice after the repo is
#       first copied.
# renv::init()
renv::restore()

suppressPackageStartupMessages({
  library("arrow")        # For reading in the data
  library("dplyr")        # For data manipulation
  library("ggplot2")      # For creating static visualizations
  library("plotly")       # For interactive plots
  library("cowplot")      # ggplot add-on for composing figures
  library("tigris")       # Imports TIGER/Line shapefiles from the Census Bureau
  library("sf")           # Handles "Simple Features": spatial vector data
  library("RColorBrewer") # Load ColorBrewer color palettes
  library("viridis")      # Load the Viridis color palette
})

# Function to select "Not In"
'%!in%' <- function(x,y)!('%in%'(x,y))




## ----------------------------------------------------------------
## LOAD THE DATASETS

# Load the RSV-NET Infections dataset used in the workshop.
url <- "https://github.com/ysph-dsde/Book-of-Workshops/raw/refs/heads/main/Workshops/Data-Visualization-with-ggplot2/Data/RSV-NET%20Infections.gz.parquet"
df <- read_parquet(url)

# Load the diamonds dataset provided with the ggplot2 package installation.
data("diamonds")

# Call the TIGER/Line Shapefiles from the Census Bureau.
us_geo <- tigris::states(class = "sf", cb = TRUE) |>
  # Translate the geometric locations for Alaska and Hawaii to plot underneath
  # the contiguous states.
  shift_geometry()




## ----------------------------------------------------------------
## SUGGESTED SOLUTIONS TO THE LECTURE DISCUSSIONS

## You can find the context for these discussion questions by reviewing
## the slides and the Book of Workshops webpage for the worked-through example:
## https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Data-Visualization-with-ggplot2/Pages/visualization-worked-through-example.html


## ---------------------
## DISCUSSION #1 - THE GEOMETRY LAYER

## The following two plots give the same results but map the aesthetics in
## different layers.

# Map aesthetics in the plot object layer
df |>
  filter(Region == "Connecticut", Season == "2021-22", Level == "N/A") |>
  ggplot(aes(x = MMWRweek, y = Kernel)) +
    geom_line()

# Map aesthetics in the Geometry layer
df |>
  filter(Region == "Connecticut", Season == "2021-22", Level == "N/A") |>
  ggplot() +
    geom_line(aes(x = MMWRweek, y = Kernel))


## Can you think of reasons why you would choose one over the other?

## It’s optional to define the data and mapping in the global ggplot() object
## or within the geometry layer itself. When generating complex plots that apply
## the same data and/or mappings, it is best practice to define them in the 
## ggplot() object. This passes the settings down to subsequently defined layers.
##
## Anytime you add a data and/or mapping term in new statistical or geometry
## layers, you override the previously defined settings. If you plan to apply
## unique data and mappings for each layer, then defining them in ggplot()
## might be unnecessary.




## ---------------------
## DISCUSSION #2 - THE SCALES LAYER

# Specify the infection seasons we'd like to see out of the range of options
include_seeasons <- c("2022-23", "2023-24", "2024-25")

## We see that associating a variable with aes(color) will also group by that 
## same variable.

# Use Scales to highlight insights into infection trends across seasons
df |>
  filter(Region == "Connecticut", Season %in% include_seeasons, Level == "N/A") |>
  ggplot(aes(x = MMWRweek, y = Kernel, color = Season) ) +
    geom_line()


## a. What would happen if we only group the outcomes and exclude the color statement: 
##    i.e., aes(group = Season)?

df |>
  filter(Region == "Connecticut", Season %in% include_seeasons, Level == "N/A") |>
  ggplot(aes(x = MMWRweek, y = Kernel, group = Season) ) +
    geom_line()

## The trendlines separate based on the "Season" groupings, but they
## do not each get a color.


## b. Does adding a scale_color_*() statement change the result?

df |>
  filter(Region == "Connecticut", Season %in% include_seeasons, Level == "N/A") |>
  ggplot(aes(x = MMWRweek, y = Kernel, group = Season) ) +
    geom_line() +
    scale_color_brewer(type = "qual", palette = "Dark2")

## No change.


## c. Why do you see the result you get?

## The Scales layer can only modify or interpret a predefined Mapping. Because
## we did not map the grouped trendlines to their own colors, user-provided
## Scales will not change the result.
##
## Notice that when we apply aes(color = Season), it both groups the data by the
## discrete outcomes in that variable and assigns a color to each unique outcome.




## ---------------------
## DISCUSSION #3 - THE COORDINATES LAYER

## In this discussion, we will follow the example laid out in the ggplot2
## package documentation for coord_trans().
## 
## Sources: https://ggplot2.tidyverse.org/reference/coord_trans.html
##          https://ggplot2-book.org/coord.html#transformations-with-coord_trans
## 
## The example uses one of the sample datasets included with the ggplot2
## installation. The "diamonds" dataset includes characteristics of diamonds,
## such as their price, carat, cut, clarity, and color.
## 
## We will compare the price of diamonds against their carat. Both variables
## will need to be transformed using a base 10 log.

# The basic, un-transformed plot.
ggplot(diamonds, aes(carat, price)) + 
  stat_bin2d() + 
  geom_smooth(method = "lm")

## a. Create three separate plots applying the following modifications to the
##    basic plot above.
##      - Transform the variables in aes() with log10()
##      - Add a Scales layer: scale_*_log10() or scale_*_continuous(trans = "log10")
##      - Add a Coordinates with Scales layer: coord_trans(x = pow10) with
##        pow10 <- scales::exp_trans(10)

ggplot(diamonds, aes(log10(carat), log10(price))) +
  stat_bin2d() + 
  geom_smooth(method = "lm")

ggplot(diamonds, aes(carat, price)) + 
  stat_bin2d() + 
  geom_smooth(method = "lm") +
  scale_x_log10() + 
  scale_y_log10()

# Fit on a log scale, then back-transform to the original scale.
pow10 <- scales::exp_trans(10)
ggplot(diamonds, aes(carat, price)) + 
  stat_bin2d() + 
  geom_smooth(method = "lm") +
  scale_x_log10() + 
  scale_y_log10() + 
  coord_trans(x = pow10, y = pow10)


## b. Do they all plot the same way? If not, what do you think is happening and 
##    how would you fix the code?

## The differences between each approach are best seen when modeling a 
## linearization of the data. Applying the transformation prior to plotting or 
## in the aes() mapping layer looks the same as the Scales variation.
##
## When the Coordinates layer is applied to the transformed data for linear
## regression, it demonstrates how the untransformed linear model fitting appears.
##
## This is because we can transform the data in two places: in Scales or in
## Coordinates. Transforming with Scales occurs before statistics are computed
## and does not change the shape of the fitted line. Transforming with
## Coordinates occurs after statistics are computed and does affect the shape 
## of the fitted line.
##
## If you are modeling data on a transformed scale and want to plot it on 
## transformed axes, you will need to apply both layers to see the correct result.
##
## More guidance on this question can be found at: https://ggplot2-book.org/coord.html#transformations-with-coord_trans




## ----------------------------------------------------------------
## SUGGESTED SOLUTIONS TO THE CHALLENGE QUESTIONS

## ---------------------
## QUESTION #1 - THE FACETS LAYER

# Copying the subsetting vectors for Season and Characteristic Level
include_seasons <- c("2022-23", "2023-24", "2024-25")
ages_ordered <- c("5-17 Years", "18-49 Years", "75+ Years")

## In the worked-through example, we leverage two of the three distinguishing
## variables: Season and Characteristic Level. In this question, we want to
## focus on the third one, Region.
##
## Recall the available outcomes for Region.
df$Region |> unique()


## Using the final line-graph code from the worked-through example, add a
## row-wise facet to compare two states or HHS regions.

# List the HHS regions we want to plot.
include_regions <- c("Region 1", "Region 4")

# Recalculate the subset for our leading point.
leading_point = df |> 
  filter(Region %in% include_regions, Season %in% include_seasons, 
         Level %in% ages_ordered) |>
  filter(MMWRyear == max(MMWRyear)) |>
  filter(MMWRweek == max(MMWRweek))

# Define our plot object.
p <- df |>
  filter(Region %in% include_regions, Season %in% include_seeasons, Level %in% ages_ordered) |>
  ggplot(aes(x = MMWRweek, y = Kernel, color = Season) ) +
    geom_line() +
    geom_point(data = leading_point, aes(x = MMWRweek, y = Kernel), 
               color = "red") +
    labs(title = "RSV Infection Trends Since 2022",
         x = "Weeks Since July", 
         y = "Positive RSV Tests\nResults Scaled and Gaussian Kernel Smoothed") +
    ylim(0, 100) +
    scale_color_brewer(type = "qual", palette = "Dark2") +
    facet_grid(~factor(Level, levels = ages_ordered)) +
    theme_linedraw()

# Apply faceting.
p + facet_grid(Region~factor(Level, levels = ages_ordered))




## ---------------------
## QUESTION #2 - OVERLAYING LAYERS

## In the polished version of the line plot, we layered an additional point
## on the graph to highlight the most recent date in the active infection season.
## To get this data, we externally filtered down the dataset to get that point,
## repeating some of the filtering we are already doing before the plot gets 
## generated.
##
## a. Can you modify this approach so that we no longer require the external
##    dataset, thus simplifying our code?
## 
## b. Now try using stat_summary(filtered_data, geom = "point", fun = "max", 
##    color = "red") instead of geom_point(). If you only filter to MMWRyear, do
##    you get the same result, and if not why?

df %>%
  filter(Region == "Connecticut", Season %in% include_seasons, 
         Level %in% ages_ordered) %>%
  #-- Wrap the entire ggplot() object with the anonymous function assigning the
  #-- left result to the variable "y." Notice that we now need to change the
  #-- pipe from base R's "|>" to tidyverse's "%>%" to allow this operation.
  (\(y) { 
    ggplot(y, aes(x = MMWRweek, y = Kernel, color = Season)) +
      geom_line() +
      
      #-- Sequentially filter the data frame (here represented as "y") by MMWRyear
      #-- and then by MMWRweek. NOTE: these operations must be done sequentially
      #-- as opposed to within the same filter() expression.
      geom_point(data = filter(y, MMWRyear == max(MMWRyear)) %>% 
                   filter(MMWRweek == max(MMWRweek)), color = "red") +
      
      #-- Alternatively, you can nest the two filter() statements:
      #geom_point(data = filter(filter(y, MMWRyear == max(MMWRyear)), 
      #                         MMWRweek == max(MMWRweek)), color = "red") +
      
      #-- Using stat_summary() instead will plot the max y detected for each
      #-- available x.
      #stat_summary(data = filter(y, MMWRyear == max(MMWRyear)), 
      #             geom = "point", fun = "max", color = "red") +
      
      #-- For example, if we filter by MMWRweek instead of MMWRyear, we get a
      #-- point at the max y detected at the max week.
      #stat_summary(data = filter(y, MMWRweek == max(MMWRweek)), 
      #             geom = "point", fun = "max", color = "red") +
      
      #-- Technically, we can do a sequential filter() over both variables,
      #-- but this operation is redundant because there is nothing left to
      #-- calculate the max over. It is therefore better to use geom_point().
      #stat_summary(data = filter(y, MMWRyear == max(MMWRyear)) %>% 
      #               filter(MMWRweek == max(MMWRweek)), 
      #             geom = "point", fun = "max", color = "red") +
      
      labs(title = "RSV Infection Trends Since 2022",
           x = "Weeks Since July", 
           y = "Positive RSV Tests\nResults Scaled and Gaussian Kernel Smoothed") +
      ylim(0, 100) +
      scale_color_brewer(type = "qual", palette = "Dark2") +
      facet_grid(~factor(Level, levels = ages_ordered)) + 
      theme_linedraw()
  })




## ---------------------
## QUESTION #3 - MAP PROJECTIONS

# Copying the data subsetting code
subset <- df |>
  filter(Region %in% c(datasets::state.name, "District of Columbia"),
         Season %in% "2024-25", MMWRweek %in% c(24:26))

# Copying the data joining and filtering code to add the SF polygons to our
# RSV infections metadata
geo_df <- us_geo |> 
  left_join(subset, c("NAME" = "Region")) |>
  filter(GEOID < 60)

## In our line graph, we faceted by age groups. However, when we apply a
## simple Facet layer to our map plot, the NA values get plotted in their 
## own panel.


## a. Why is this happening?

## When we joined the polygon vector dataset with our metadata dataset, we
## induced NA's for the missing states. These get registered as a new outcome
## for Level and plot separately.


## b. Fix this code to prevent this panel from being generated.

ggplot() +
  # Layers are plotted one on top of another. If we want the background to
  # show the states, we add our new layer before the data is abstracted
  # onto the map.
  geom_sf(data = filter(us_geo, GEOID < 60)) +
  # The Data layer will be inherited from the previous geom_sf().
  # Therefore, we must override the inherited setting. Notice also that we need to
  # denote the aesthetic here too. Kernel is not present in the us_geo dataset,
  # and because it comes first, we cannot place it in ggplot() without drawing
  # an error.
  geom_sf(data = na.omit(geo_df), aes(fill = Kernel), color = "black") +
  scale_fill_viridis(direction = -1, na.value = "grey92") +
  labs(fill = NULL, title = "Peak 2024-25 Season RSV Infection Trends\nResults Scaled and Gaussian Kernel Smoothed") +
  facet_grid(~factor(Level, levels = ages_ordered)) + 
  coord_sf() +
  theme_map()




