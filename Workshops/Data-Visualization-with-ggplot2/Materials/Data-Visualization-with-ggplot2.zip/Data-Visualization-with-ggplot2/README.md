# Data Visualization with `ggplot2`.

## About The Coffee, Cookie and Coding $\left(C^3\right)$ Workshops

Yale's [Public Health Data Science and Data Equity (DSDE)](https://ysph.yale.edu/research/research-centers-and-initiatives/public-health-data-science-and-data-equity/) team hosts workshops, tutorials, and information sessions known as Coffee, Cookie and Coding $\left(C^3\right)$ Workshops. These sessions are designed to help Public Health and Biostatistics masters-level students at Yale effectively leverage computational tools and analytical methods in their educational and professional endeavors. While primarily intended for the Yale community, all are welcome and encouraged to attend and benefit from our offerings.

You can find out more about past and upcoming work on our [website](https://ysph.yale.edu/public-health-research-and-practice/research-centers-and-initiatives/public-health-data-science-and-data-equity/events/). Additional tutorials will soon be available on our YouTube channel. If you are affiliated with Yale, you can set up an office hour appointment with one of our data scientists on our [Bookings Page](https://outlook.office365.com/book/DataScienceDataEquityOfficeHours@yale.edu/?ismsaljsauthenabled=true).

## About Workshop

All workshop details and content, including slides, handouts, and adaptations for asynchronous learning, are available on our [Book of Workshops](https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Data-Visualization-with-ggplot2/visualization-index.html) webpage for the session. Please note that the workshop slides summarize the code for the plots. Visit the [Worked-Through Example](https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Data-Visualization-with-ggplot2/Pages/visualization-worked-through-example.html) page for the complete code.

**Instructor:** [Shelby Golden, M.S.](https://www.linkedin.com/in/shelby-golden/), Data Scientist I

**Learning Goals:**

-   Classify the Grammar of Graphics layers used in `ggplot` syntax.
-   Applications of different geometries, effective use of layering, and polishing the result.
-   Interactive plots, map projections, and leverage AI assisted coding.

## Overview Of Contents

-   **R Project:** `Data-Visualization-with-ggplot2.Rproj`
-   **Discussion and Challenge Questions Code:** `Discussion and Challenge Questions.R`
-   **Discussion and Challenge Questions Solutions:** `Discussion and Challenge Questions_Solutions.R`
-   `renv` version: 1.1.5. This is included to reproduce the coding environment.
-   `.gitignore`: This file tells Git to ignore specific files or file types that do not need to be, or should not be, version controlled and shared with the remote GitHub repository. On some devices, this file might be hidden depending on your settings.

## Using this Repository

This directory includes the codebase for discussion and challenge questions prepared for the session participants. Solutions to the lecture discussions and challenge questions are provided in a separate `*.R` file. To fully engage with these materials, please follow the detailed setup instructions provided under [Accessing the Codespaces](https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Data-Visualization-with-ggplot2/visualization-index.html#accessing-the-codespaces).

Please note that all slides, handouts, and code provided in this workshop, including any code added to your personal repository, belongs to DSDE. When using or referencing this material, please ensure to cite it correctly to give proper credit to the original authors.

## About the Data

Respiratory syncytial virus (RSV) is a common virus that infects the nose, throat, and lungs, spreading mainly in fall and winter, with peaks in December and January. While it often causes mild illness in healthy individuals, it can lead to hospitalization in infants under six months and older adults. RSV can cause severe illnesses like bronchiolitis and pneumonia, especially in children under one year, making it a leading cause of these conditions. For more information, visit the CDC's [About RSV](https://www.cdc.gov/rsv/about/index.html) page.

National trends of RSV infections are monitored through the Centers for Disease Control and Prevention’s (CDC) Respiratory Virus Hospitalization Surveillance Network, known as RSV-NET. RSV-NET is one of three programs that make up the Respiratory Virus Hospitalization Surveillance Network (RESP-NET), alongside the Coronavirus Disease 2019 (COVID-19) Hospitalization Surveillance Network (COVID-NET) and the Influenza Hospitalization Surveillance Network (FluSurv-NET).

As of this writing, 161 counties and county equivalents across 13 states participate in RSV-NET by submitting data on laboratory-confirmed, RSV-associated hospitalizations among children and adults. This surveillance network covers approximately 30 million people, representing about 9% of the U.S. population. Although its demographic representation is comparable to the overall U.S. population, it may not be fully generalizable to the entire country. For more information, visit the CDC's information page about [RSV-NET](https://www.cdc.gov/rsv/php/surveillance/rsv-net.html).

The cleaned and harmonized version of the RSV-NET dataset was compiled as part of YSPH’s [PopHIVE](https://www.pophive.org/) project. It reflects data downloaded from the *Weekly Rates of Laboratory-Confirmed RSV Hospitalizations from the RSV-NET Surveillance System* page on [data.gov](https://data.cdc.gov/Public-Health-Surveillance/Weekly-Rates-of-Laboratory-Confirmed-RSV-Hospitali/29hc-w46k/about_data), which is updated weekly and accessible via the RSV-NET surveillance program's [interactive dashboard](https://www.cdc.gov/rsv/php/surveillance/rsv-net.html). The original data used was downloaded on December 23^rd^, 2024. The code used to prepare the dataset for this module can be found in the YSPH DSDE's Book of Workshops GitHub repository: [Data-Visualization-with-ggplot2/Code/Cleaning Script.R](https://github.com/ysph-dsde/Book-of-Workshops/blob/main/Workshops/Data-Visualization-with-ggplot2/Code/Cleaning%20Script.R).

## References

1. Answered by Hong Ooi, “lm() within mutate() in group_by(),” Stack Overflow. Accessed: Mar. 17, 2025. [Online]. Available: https://stackoverflow.com/questions/40060828/lm-within-mutate-in-group-by
2. Centers for Disease Control and Prevention (CDC), “MMWR Weeks Definition”, Accessed: Mar. 14, 2025. [Online]. Available: https://ndc.services.cdc.gov/wp-content/uploads/MMWR_week_overview.pdf
3. Centers for Disease Control and Prevention (CDC), “Respiratory Syncytial Virus Hospitalization Surveillance Network (RSV-NET),” cdc.gov. Accessed: Mar. 24, 2025. [Online]. Available: https://www.cdc.gov/rsv/php/surveillance/rsv-net.html
4. Centers for Disease Control and Prevention (CDC), “About RSV.” Accessed: Jul. 15, 2025. [Online]. Available: https://www.cdc.gov/rsv/about/index.html
5. Centers for Disease Control and Prevention (CDC), “Respiratory Virus Hospitalization Surveillance Network (RESP-NET).” Accessed: Jul. 15, 2025. [Online]. Available: https://www.cdc.gov/resp-net/dashboard/
6. R. Zhu, “Statistical Learning and Machine Learning with R.” Accessed: Mar. 17, 2025. [Online]. Available: https://teazrq.github.io/SMLR/kernel-smoothing.html
7. S. Golden, “Data Visualization with ggplot2.” Accessed: Nov. 22, 2025. [Online]. Available: https://ysph-dsde.github.io/Book-of-Workshops/Workshops/Data-Visualization-with-ggplot2/visualization-index.html
8. H. Wickham, D. Navarro, and T. L. Pedersen, 15 Coordinate systems – ggplot2: Elegant Graphics for Data Analysis (3e), Springer. Springer, 2010. Accessed: Nov. 22, 2025. [Online]. Available: https://ggplot2-book.org/coord.html#transformations-with-coord_trans
9. Yale School of Public Health, “PopHIVE.” Accessed: Jul. 15, 2025. [Online]. Available: https://www.pophive.org/
10. “Weekly Rates of Laboratory-Confirmed RSV Hospitalizations from the RSV-NET Surveillance System,” CDC’s data.gov. Accessed: Jan. 28, 2025. [Online]. Available: https://data.cdc.gov/Public-Health-Surveillance/Weekly-Rates-of-Laboratory-Confirmed-RSV-Hospitali/29hc-w46k/about_data